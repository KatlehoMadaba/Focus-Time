# Focus Time App


## Basics
JSX = javascript markup

export default - exports one main thing
flex: 1 - fills in the full screen

terenery if works like this - condition ? exprIfTrue : exprIfFalse


## Interesting shit to know
styles.container = object.attribute - this is basically how most things work in react they typically work with objects

difference between export default and export const 
  default = import Focus from 'src/feature/focus/focus'
  const = this is a named export import { Focus } from 'src/feature/focus/focus'
  one is a named export one is not